﻿Hi user, I’m Aiden, a developer that makes PEXTs to install programs on your PearOS ThiccSur Computer.
The programs I publish on GitHub are licensed under the GNU General Public License (GPL) v3.0.
The names PearOS ThiccSur and PEXT are trademarks of Pear.

